import React from 'react'
import Button from './Button.css'

export default props => 
    <button 
        onClick={e => props.click && props.click(props.label)}
        className={`
            btn
            ${props.operation ? 'operation' : ''}
            ${props.double ? 'double' : ''}
            ${props.triple ? 'triple' : ''}
    `}>
        {props.label}
    </button>