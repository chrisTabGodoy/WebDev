//sass archives
import './scss/index.scss'

//dependecies
import 'jquery'
import 'bootstrap'

//my js archives
import './js/core/includes'
import './js/plugins/cityButtons'